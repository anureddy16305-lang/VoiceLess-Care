export function speak(text) {
  if ('speechSynthesis' in window) {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 0.9;
    speechSynthesis.speak(u);
  }
}

export function downloadText(text, filename='voiceforall_medical_script.txt') {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function printScript(script) {
  const win = window.open('', '_blank');
  win.document.write(`<html><head><title>VoiceForAll Medical Script</title><style>body{font-family:Arial;padding:30px;line-height:1.6}h1{color:#2563eb;text-align:center}pre{white-space:pre-wrap;font-size:15px;border:1px solid #ddd;padding:20px;border-radius:12px}</style></head><body><h1>VoiceForAll Medical Script</h1><pre>${script}</pre></body></html>`);
  win.document.close();
  win.print();
}
