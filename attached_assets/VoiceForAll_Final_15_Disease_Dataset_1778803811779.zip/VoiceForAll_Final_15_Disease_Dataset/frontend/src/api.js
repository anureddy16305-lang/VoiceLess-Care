import axios from 'axios';

const API = 'http://127.0.0.1:5000/api';

export const checkBackend = () => axios.get(`${API}/health`).then(r => r.data);

export const analyzeGesture = (patient, symptom, confidence = 85) =>
  axios.post(`${API}/analyze/camera`, { patient, symptom, confidence }).then(r => r.data);

export const sendTextScript = (patient, message) =>
  axios.post(`${API}/script/text`, { patient, message }).then(r => r.data);

export const sendVoiceScript = (patient, audio, transcript = '') => {
  const form = new FormData();
  form.append('audio', audio, 'voiceforall_recording.webm');
  form.append('name', patient.name);
  form.append('age', patient.age);
  form.append('gender', patient.gender);
  form.append('transcript', transcript);
  return axios.post(`${API}/script/voice`, form).then(r => r.data);
};
