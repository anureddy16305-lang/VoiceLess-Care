import React, { useEffect, useRef, useState } from 'react';
import { checkBackend, analyzeGesture, sendTextScript, sendVoiceScript } from './api';
import { downloadText, printScript, speak } from './utils';
import './App.css';

function estimateGesture(handLandmarks) {
  if (!handLandmarks) return { symptom: 'normal', label: 'No clear sign detected', confidence: 0 };

  const wrist = handLandmarks[0];
  const indexTip = handLandmarks[8];
  const middleTip = handLandmarks[12];
  const thumbTip = handLandmarks[4];

  const avgX = (wrist.x + indexTip.x + middleTip.x + thumbTip.x) / 4;
  const avgY = (wrist.y + indexTip.y + middleTip.y + thumbTip.y) / 4;

  // Camera zones are mapped to natural health-sign body actions.
  if (avgY < 0.18) return { symptom: 'fever', label: 'Hand on forehead: Fever', confidence: 88 };
  if (avgY >= 0.18 && avgY < 0.30 && avgX > 0.25 && avgX < 0.75) return { symptom: 'headache', label: 'Hand on head/temples: Headache', confidence: 90 };
  if (avgY >= 0.30 && avgY < 0.40 && avgX > 0.35 && avgX < 0.65) return { symptom: 'throat_problem', label: 'Hand holding throat: Throat problem', confidence: 86 };
  if (avgY >= 0.40 && avgY < 0.52 && avgX > 0.30 && avgX < 0.70) return { symptom: 'chest_pain', label: 'Hand on chest: Chest pain', confidence: 91 };
  if (avgY >= 0.52 && avgY < 0.67 && avgX > 0.25 && avgX < 0.75) return { symptom: 'stomach_pain', label: 'Hand on stomach: Stomach pain', confidence: 88 };
  if (avgY >= 0.67 && avgX > 0.35 && avgX < 0.65) return { symptom: 'severe_stomach_pain', label: 'Hands on lower abdomen: Severe stomach pain', confidence: 84 };

  if (avgY < 0.38 && avgX < 0.30) return { symptom: 'vomiting', label: 'Hand near mouth: Vomiting', confidence: 80 };
  if (avgY < 0.34 && avgX > 0.70) return { symptom: 'eye_problem', label: 'Hand near eye: Eye problem', confidence: 78 };
  if (avgY > 0.40 && avgX < 0.23) return { symptom: 'weakness', label: 'Weak posture: Weakness', confidence: 76 };
  if (avgY > 0.40 && avgX > 0.77) return { symptom: 'emergency', label: 'Help gesture: Emergency', confidence: 78 };

  return { symptom: 'injury', label: 'Holding painful area: Injury / body pain', confidence: 70 };
}

export default function App() {
  const videoRef = useRef(null);
  const lastGestureRef = useRef(null);
  const stableRef = useRef({ symptom: '', count: 0 });
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);

  const [backend, setBackend] = useState('checking');
  const [step, setStep] = useState('profile');
  const [patient, setPatient] = useState({ name: '', age: '', gender: '' });
  const [mode, setMode] = useState('');
  const [cameraRunning, setCameraRunning] = useState(false);
  const [detected, setDetected] = useState(null);
  const [message, setMessage] = useState('');
  const [recordedAudio, setRecordedAudio] = useState(null);
  const [audioUrl, setAudioUrl] = useState('');
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [recording, setRecording] = useState(false);
  const [result, setResult] = useState(null);
  const [script, setScript] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    checkBackend().then(() => setBackend('online')).catch(() => setBackend('offline'));
  }, []);

  function submitProfile() {
    if (!patient.name.trim() || !patient.age.trim() || !patient.gender.trim()) {
      alert('Please enter name, age and gender.');
      return;
    }
    setStep('mode');
  }

  async function startCamera() {
    try {
      if (!window.Hands || !window.Camera) {
        alert('MediaPipe not loaded. Please keep internet on and refresh.');
        return;
      }

      const hands = new window.Hands({ locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}` });
      hands.setOptions({ maxNumHands: 1, modelComplexity: 1, minDetectionConfidence: 0.65, minTrackingConfidence: 0.65 });

      hands.onResults((results) => {
        if (!results.multiHandLandmarks || results.multiHandLandmarks.length === 0) {
          setDetected({ symptom: 'normal', label: 'Show health sign clearly', confidence: 0 });
          lastGestureRef.current = null;
          return;
        }

        const guess = estimateGesture(results.multiHandLandmarks[0]);
        if (stableRef.current.symptom === guess.symptom) stableRef.current.count += 1;
        else stableRef.current = { symptom: guess.symptom, count: 1 };

        const finalGuess = { ...guess, confidence: Math.min(guess.confidence + stableRef.current.count, 96) };
        setDetected(finalGuess);
        lastGestureRef.current = finalGuess;
      });

      const camera = new window.Camera(videoRef.current, {
        onFrame: async () => await hands.send({ image: videoRef.current }),
        width: 640,
        height: 480
      });

      camera.start();
      setCameraRunning(true);
    } catch {
      alert('Camera permission denied or camera not found.');
    }
  }

  async function analyzeDetectedGesture() {
    if (!lastGestureRef.current || lastGestureRef.current.confidence < 60) {
      alert('Please show symptom sign clearly to camera.');
      return;
    }

    setLoading(true);
    try {
      const data = await analyzeGesture(patient, lastGestureRef.current.symptom, lastGestureRef.current.confidence);
      setResult(data.result);
      setScript(data.script);
      speak(`${data.result.status}. ${data.result.disease}. ${data.result.advice}`);
    } catch {
      alert('Backend not running. Please start backend.');
    }
    setLoading(false);
  }

  async function handleText() {
    if (!message.trim()) return alert('Please type symptoms.');
    setLoading(true);
    try {
      const data = await sendTextScript(patient, message);
      setResult(data.result);
      setScript(data.script);
      speak(`${data.result.status}. ${data.result.disease}. ${data.result.advice}`);
    } catch {
      alert('Backend not running. Please start backend.');
    }
    setLoading(false);
  }

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      chunksRef.current = [];
      const recorder = new MediaRecorder(stream);
      recorder.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setRecordedAudio(blob);
        setAudioUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach(t => t.stop());
      };
      recorderRef.current = recorder;
      recorder.start();
      setRecording(true);
    } catch {
      alert('Microphone permission denied.');
    }
  }

  function stopRecording() {
    if (recorderRef.current && recording) {
      recorderRef.current.stop();
      setRecording(false);
    }
  }

  async function handleVoice() {
    if (!recordedAudio) return alert('Please record voice first.');
    setLoading(true);
    try {
      const data = await sendVoiceScript(patient, recordedAudio, voiceTranscript);
      setResult(data.result);
      setScript(data.script);
      speak('Voice recording converted to medical script.');
    } catch {
      alert('Backend not running. Please start backend.');
    }
    setLoading(false);
  }

  return (
    <div className="app">
      <header>
        <div className="logo">🤟 VoiceForAll</div>
        <div className={`backend ${backend}`}>Backend: {backend === 'online' ? 'Online ✅' : backend === 'offline' ? 'Offline ❌' : 'Checking...'}</div>
      </header>

      <main>
        <section className="hero">
          <h1>15-Disease ISL Health Chatbot</h1>
          <p>Body-action based sign detection for chest pain, headache, fever, breathing issue, stomach pain, injury, emergency and more.</p>
        </section>

        {step === 'profile' && (
          <section className="card center">
            <h2>Chatbot: Please enter patient details</h2>
            <div className="form-grid">
              <input placeholder="Patient Name" value={patient.name} onChange={e => setPatient({...patient, name: e.target.value})}/>
              <input placeholder="Age" type="number" value={patient.age} onChange={e => setPatient({...patient, age: e.target.value})}/>
              <select value={patient.gender} onChange={e => setPatient({...patient, gender: e.target.value})}>
                <option value="">Select Gender</option>
                <option>Female</option>
                <option>Male</option>
                <option>Other</option>
              </select>
            </div>
            <button className="btn primary" onClick={submitProfile}>Continue</button>
          </section>
        )}

        {step === 'mode' && (
          <section className="card center">
            <h2>Hello {patient.name}, choose communication method</h2>
            <div className="mode-grid">
              <button className="mode-card" onClick={() => {setMode('camera'); setStep('work')}}>📷 Live Health Sign</button>
              <button className="mode-card" onClick={() => {setMode('voice'); setStep('work')}}>🎙️ Voice Recording</button>
              <button className="mode-card" onClick={() => {setMode('text'); setStep('work')}}>⌨️ Typing</button>
            </div>
          </section>
        )}

        {step === 'work' && (
          <div className="grid">
            <section className="card">
              <button className="back" onClick={() => setStep('mode')}>← Change Option</button>
              <h2>{mode === 'camera' ? 'Live Health-Sign Detection' : mode === 'voice' ? 'Voice Recording' : 'Typing Symptoms'}</h2>

              {mode === 'camera' && (
                <>
                  <video ref={videoRef} autoPlay playsInline muted className="video"></video>
                  <button className="btn secondary" onClick={startCamera}>{cameraRunning ? 'Camera Running' : 'Open Camera'}</button>
                  <div className="detected">
                    <b>{detected?.label || 'Waiting for health sign...'}</b>
                    <p>Confidence: {detected?.confidence || 0}%</p>
                    <small>Show: hand on chest, head, forehead, throat, stomach, mouth, eye, back, ear, or emergency gesture.</small>
                  </div>
                  <button className="btn primary" onClick={analyzeDetectedGesture}>{loading ? 'Analyzing...' : 'Analyze Sign & Create Script'}</button>
                </>
              )}

              {mode === 'voice' && (
                <>
                  <div className="recorder">
                    <button className="btn danger" onClick={startRecording} disabled={recording}>Start Recording</button>
                    <button className="btn secondary" onClick={stopRecording} disabled={!recording}>Stop Recording</button>
                    <b>{recording ? 'Recording...' : recordedAudio ? 'Recording saved ✅' : 'No recording yet'}</b>
                  </div>
                  {audioUrl && <audio controls src={audioUrl}></audio>}
                  <textarea placeholder="Optional: type what patient said for better analysis..." value={voiceTranscript} onChange={e => setVoiceTranscript(e.target.value)}></textarea>
                  <button className="btn primary" onClick={handleVoice}>{loading ? 'Converting...' : 'Convert Recording To Script'}</button>
                </>
              )}

              {mode === 'text' && (
                <>
                  <textarea placeholder="Type symptoms here..." value={message} onChange={e => setMessage(e.target.value)}></textarea>
                  <button className="btn primary" onClick={handleText}>{loading ? 'Analyzing...' : 'Analyze & Create Script'}</button>
                </>
              )}
            </section>

            <section className={`card report ${result?.status === 'CRITICAL' ? 'critical' : result ? 'normal' : ''}`}>
              <h2>Printable Medical Script</h2>
              {result ? (
                <>
                  <div className="result">
                    <p><b>Detected:</b> {result.gesture}</p>
                    <p><b>Possible Issue:</b> {result.disease}</p>
                    <p><b>Status:</b> {result.status}</p>
                    <p><b>Advice:</b> {result.advice}</p>
                  </div>
                  <pre>{script}</pre>
                  <button className="btn success" onClick={() => downloadText(script)}>Download Script</button>
                  <button className="btn secondary" onClick={() => printScript(script)}>Print Script</button>
                  {result.status === 'CRITICAL' && (
                    <div className="map">
                      <h3>Nearby Hospitals</h3>
                      <iframe title="hospital map" src="https://www.google.com/maps?q=hospitals+near+me&output=embed" width="100%" height="260" loading="lazy"></iframe>
                    </div>
                  )}
                </>
              ) : <p>No script yet. Choose a method and analyze symptoms.</p>}
            </section>
          </div>
        )}
      </main>
    </div>
  );
}
