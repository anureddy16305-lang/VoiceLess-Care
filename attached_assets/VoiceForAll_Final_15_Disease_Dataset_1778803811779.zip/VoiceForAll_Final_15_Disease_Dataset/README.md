# VoiceForAll Final 15 Disease Dataset Project

## Included
- Final Flask backend
- Final React + Vite frontend
- 15 health gesture dataset folder structure
- Dataset labels CSV
- Gesture map JSON
- Dataset capture script

## Run Backend
```powershell
cd Downloads
cd VoiceForAll_Final_15_Disease_Dataset
cd VoiceForAll_Final_15_Disease_Dataset
cd backend
pip install -r requirements.txt
python app.py
```

## Run Frontend
Open new terminal:
```powershell
cd Downloads
cd VoiceForAll_Final_15_Disease_Dataset
cd VoiceForAll_Final_15_Disease_Dataset
cd frontend
npm install
npm run dev
```

Open:
http://localhost:5173

## Collect Dataset Images
```powershell
cd Downloads
cd VoiceForAll_Final_15_Disease_Dataset
cd VoiceForAll_Final_15_Disease_Dataset
cd scripts
pip install -r requirements.txt
python capture_dataset.py
```

SPACE = capture image
Q = quit

## Critical Classes
- chest_pain
- severe_chest_pain
- breathing_problem
- severe_stomach_pain
- emergency
- injury

## Normal Classes
- fever
- headache
- throat_problem
- stomach_pain
- vomiting
- eye_problem
- ear_problem
- back_pain
- weakness
