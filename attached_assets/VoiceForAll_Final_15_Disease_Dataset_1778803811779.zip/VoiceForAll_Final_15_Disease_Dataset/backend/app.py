from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from io import BytesIO
import datetime

app = Flask(__name__)
CORS(app)

DISEASES = {
    "chest_pain": {
        "gesture": "Hand on Chest",
        "disease": "Heart pain / Chest pressure / Possible heart problem",
        "status": "CRITICAL",
        "advice": "Go to the nearest hospital immediately. Do not ignore chest pain."
    },
    "severe_chest_pain": {
        "gesture": "Both Hands on Chest",
        "disease": "Serious cardiac emergency / Heart attack risk",
        "status": "CRITICAL",
        "advice": "Call ambulance or go to emergency care immediately."
    },
    "fever": {
        "gesture": "Hand on Forehead",
        "disease": "Fever / Viral infection",
        "status": "NORMAL",
        "advice": "Drink fluids, rest, and check temperature regularly."
    },
    "headache": {
        "gesture": "Hand Pressing Head or Temples",
        "disease": "Headache / Migraine / Stress",
        "status": "NORMAL",
        "advice": "Take rest, drink water, avoid screen time, and consult doctor if severe."
    },
    "throat_problem": {
        "gesture": "Hand Holding Throat",
        "disease": "Throat pain / Throat infection",
        "status": "NORMAL",
        "advice": "Gargle with warm salt water and consult doctor if pain continues."
    },
    "breathing_problem": {
        "gesture": "Hand Near Throat / Breathing Difficulty",
        "disease": "Asthma / Respiratory issue / Breathing problem",
        "status": "CRITICAL",
        "advice": "Needs urgent medical help. Sit upright and go to hospital if breathing is difficult."
    },
    "stomach_pain": {
        "gesture": "Hand on Stomach",
        "disease": "Stomach pain / Gastric / Food poisoning",
        "status": "NORMAL",
        "advice": "Eat light food, drink water, and consult doctor if pain increases."
    },
    "severe_stomach_pain": {
        "gesture": "Both Hands on Lower Abdomen",
        "disease": "Severe abdominal pain / Appendix risk",
        "status": "CRITICAL",
        "advice": "Visit hospital urgently if stomach pain is severe or continuous."
    },
    "vomiting": {
        "gesture": "Hand Near Mouth Vomiting Action",
        "disease": "Vomiting / Nausea / Dehydration",
        "status": "NORMAL",
        "advice": "Drink ORS, take rest, and avoid oily food."
    },
    "eye_problem": {
        "gesture": "Hand on Eyes",
        "disease": "Eye strain / Eye infection / Eye pain",
        "status": "NORMAL",
        "advice": "Avoid screen exposure and consult an eye doctor if severe."
    },
    "ear_problem": {
        "gesture": "Hand on Ear",
        "disease": "Ear pain / Ear infection",
        "status": "NORMAL",
        "advice": "Avoid inserting anything in the ear and consult doctor if pain continues."
    },
    "back_pain": {
        "gesture": "Hand Holding Back",
        "disease": "Back pain / Spine pain / Muscle pain",
        "status": "NORMAL",
        "advice": "Take rest, avoid lifting heavy objects, and use warm compress."
    },
    "weakness": {
        "gesture": "Weak / Falling Posture",
        "disease": "Weakness / Low BP / Dizziness",
        "status": "NORMAL",
        "advice": "Sit down, drink water, and eat something light."
    },
    "emergency": {
        "gesture": "Both Hands Waving for Help",
        "disease": "Emergency condition",
        "status": "CRITICAL",
        "advice": "Call ambulance immediately or go to nearest hospital."
    },
    "injury": {
        "gesture": "Holding Injured Area / Bleeding Sign",
        "disease": "Injury / Accident / Bleeding",
        "status": "CRITICAL",
        "advice": "Apply first aid and visit nearest hospital immediately."
    },
    "normal": {
        "gesture": "Normal",
        "disease": "No critical symptom detected",
        "status": "NORMAL",
        "advice": "Stay healthy and hydrated."
    }
}

TEXT_KEYWORDS = {
    "chest": "chest_pain", "heart": "chest_pain", "pressure": "chest_pain",
    "severe chest": "severe_chest_pain", "heart attack": "severe_chest_pain",
    "fever": "fever", "temperature": "fever",
    "headache": "headache", "head": "headache", "migraine": "headache",
    "throat": "throat_problem",
    "breathing": "breathing_problem", "breath": "breathing_problem", "asthma": "breathing_problem",
    "stomach": "stomach_pain", "gastric": "stomach_pain",
    "severe stomach": "severe_stomach_pain", "abdomen": "severe_stomach_pain", "appendix": "severe_stomach_pain",
    "vomit": "vomiting", "vomiting": "vomiting", "nausea": "vomiting",
    "eye": "eye_problem",
    "ear": "ear_problem",
    "back": "back_pain", "spine": "back_pain",
    "weak": "weakness", "weakness": "weakness", "dizzy": "weakness",
    "emergency": "emergency", "help": "emergency",
    "injury": "injury", "bleeding": "injury", "accident": "injury"
}

SCRIPTS = []

def analyze_text_to_symptom(text):
    text = (text or "").lower()
    for keyword, symptom in TEXT_KEYWORDS.items():
        if keyword in text:
            return symptom
    return "normal"

def build_script(patient, input_mode, symptom_text, result):
    script = f"""
VOICEFORALL MEDICAL COMMUNICATION SCRIPT

Generated On: {datetime.datetime.now().strftime("%d-%m-%Y %I:%M %p")}

PATIENT DETAILS
Name: {patient.get("name", "Not provided")}
Age: {patient.get("age", "Not provided")}
Gender: {patient.get("gender", "Not provided")}

INPUT MODE
{input_mode}

PATIENT PROBLEM / SYMPTOMS
{symptom_text}

AI ANALYSIS
Detected Gesture / Symptom: {result.get("gesture")}
Possible Health Issue: {result.get("disease")}
Severity Status: {result.get("status")}
Advice: {result.get("advice")}

IMPORTANT NOTE
This is an AI-assisted communication support report.
It is not a final medical diagnosis.
Please consult a qualified doctor for final diagnosis and treatment.
"""
    return script.strip()

def make_response(result, script, extra=None):
    response = {"success": True, "result": result, "script": script, "hospital_map": None}
    if extra:
        response.update(extra)
    if result["status"] == "CRITICAL":
        response["hospital_map"] = "https://www.google.com/maps/search/hospitals+near+me"
    return jsonify(response)

@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "service": "VoiceForAll Final 15 Disease Backend",
        "status": "running",
        "version": "final-15-disease-dataset",
        "total_classes": len(DISEASES)
    })

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "message": "Backend working successfully",
        "total_diseases": len(DISEASES)
    })

@app.route("/api/analyze/camera", methods=["POST"])
def analyze_camera():
    data = request.get_json(silent=True) or {}
    patient = data.get("patient", {})
    symptom = data.get("symptom", "normal").lower().strip()
    confidence = data.get("confidence", 0)

    result = DISEASES.get(symptom, DISEASES["normal"])
    symptom_text = f"Live camera gesture detection identified: {result['gesture']} with confidence {confidence}%."
    script = build_script(patient, "Live Camera Health Gesture Detection", symptom_text, result)
    SCRIPTS.append(script)

    return make_response(result, script, {
        "message": "Live camera gesture analyzed",
        "confidence": confidence
    })

@app.route("/api/script/text", methods=["POST"])
def text_to_script():
    data = request.get_json(silent=True) or {}
    patient = data.get("patient", {})
    message = data.get("message", "").strip()

    if not message:
        return jsonify({"success": False, "error": "Message is required"}), 400

    symptom = analyze_text_to_symptom(message)
    result = DISEASES.get(symptom, DISEASES["normal"])
    script = build_script(patient, "Typing Message", message, result)
    SCRIPTS.append(script)

    return make_response(result, script)

@app.route("/api/script/voice", methods=["POST"])
def voice_to_script():
    if "audio" not in request.files:
        return jsonify({"success": False, "error": "Recorded audio is required"}), 400

    patient = {
        "name": request.form.get("name", "Not provided"),
        "age": request.form.get("age", "Not provided"),
        "gender": request.form.get("gender", "Not provided")
    }

    transcript = request.form.get("transcript", "").strip()
    if not transcript:
        transcript = "Voice recorded successfully. Add transcript text for more accurate symptom analysis."

    symptom = analyze_text_to_symptom(transcript)
    result = DISEASES.get(symptom, DISEASES["normal"])
    script = build_script(patient, "Direct Voice Recording", transcript, result)
    SCRIPTS.append(script)

    return make_response(result, script, {"transcript": transcript})

@app.route("/api/script/download", methods=["POST"])
def download_script():
    data = request.get_json(silent=True) or {}
    script = data.get("script", "").strip()

    if not script:
        return jsonify({"success": False, "error": "Script text is required"}), 400

    file_data = BytesIO(script.encode("utf-8"))
    return send_file(
        file_data,
        as_attachment=True,
        download_name="voiceforall_medical_script.txt",
        mimetype="text/plain"
    )

@app.route("/api/script/latest/download", methods=["GET"])
def download_latest_script():
    if not SCRIPTS:
        return jsonify({"success": False, "error": "No script available"}), 404

    file_data = BytesIO(SCRIPTS[-1].encode("utf-8"))
    return send_file(
        file_data,
        as_attachment=True,
        download_name="latest_voiceforall_script.txt",
        mimetype="text/plain"
    )

@app.route("/api/diseases", methods=["GET"])
def diseases():
    return jsonify({
        "total": len(DISEASES),
        "diseases": DISEASES
    })

if __name__ == "__main__":
    app.run(debug=True, port=5000)
