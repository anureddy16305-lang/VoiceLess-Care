import cv2
from pathlib import Path

CLASSES = [
    "chest_pain", "severe_chest_pain", "fever", "headache", "throat_problem",
    "breathing_problem", "stomach_pain", "severe_stomach_pain", "vomiting",
    "eye_problem", "ear_problem", "back_pain", "weakness", "emergency", "injury"
]

BASE_DIR = Path(__file__).resolve().parent.parent
DATASET_DIR = BASE_DIR / "dataset"

def capture_class(class_name, target_count=50):
    save_dir = DATASET_DIR / class_name
    save_dir.mkdir(parents=True, exist_ok=True)
    count = len(list(save_dir.glob("*.jpg")))

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Camera not found")
        return

    print(f"Collecting: {class_name}")
    print("SPACE = capture image | Q = quit")

    while count < target_count:
        ret, frame = cap.read()
        if not ret:
            break

        preview = frame.copy()
        cv2.putText(preview, f"Class: {class_name}", (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)
        cv2.putText(preview, f"Captured: {count}/{target_count}", (20, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)
        cv2.putText(preview, "SPACE: capture | Q: quit", (20, 115), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,255), 2)

        cv2.imshow("VoiceForAll 15 Disease Dataset Collector", preview)
        key = cv2.waitKey(1) & 0xFF

        if key == ord(" "):
            filename = save_dir / f"{class_name}_{count:04d}.jpg"
            cv2.imwrite(str(filename), frame)
            print("Saved:", filename)
            count += 1
        elif key == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()

def main():
    print("VoiceForAll 15 Disease Health Gesture Dataset Collector")
    for i, cls in enumerate(CLASSES, start=1):
        print(f"{i}. {cls}")

    choice = input("Enter class number OR all: ").strip().lower()
    target = input("Images per class, default 50: ").strip()
    target_count = int(target) if target.isdigit() else 50

    if choice == "all":
        for cls in CLASSES:
            input(f"Get ready for {cls}. Press ENTER to start.")
            capture_class(cls, target_count)
    else:
        capture_class(CLASSES[int(choice) - 1], target_count)

if __name__ == "__main__":
    main()
